angular-album
=============

This is the sample project for building a photo album with AngularJS